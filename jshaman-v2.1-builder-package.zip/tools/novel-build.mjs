#!/usr/bin/env node
import fs from "node:fs/promises";
import crypto from "node:crypto";
import { parse } from "@babel/parser";

const INPUT = process.argv[2] || "origin.js";
const OUTPUT = process.argv[3] || "_worker.js";
const LIMIT = 450 * 1024;
const API = "https://www.jshaman.com:4430/submit_js_code/";
const sleep = ms => new Promise(r => setTimeout(r, ms));

function die(msg) {
  console.error(`ERROR: ${msg}`);
  process.exit(1);
}
function sha256(s) {
  return crypto.createHash("sha256").update(s).digest("hex");
}
function bytes(s) {
  return Buffer.byteLength(s, "utf8");
}
function parseJS(source) {
  try {
    return parse(source, {
      sourceType: "module",
      allowAwaitOutsideFunction: true,
      plugins: [
        "asyncGenerators","bigInt","classProperties","classPrivateProperties",
        "classPrivateMethods","dynamicImport","exportDefaultFrom",
        "exportNamespaceFrom","importMeta","logicalAssignment",
        "nullishCoalescingOperator","optionalChaining","topLevelAwait",
        "objectRestSpread","numericSeparator","optionalCatchBinding"
      ]
    });
  } catch (e) {
    die(`Babel parser failed: ${e.message}`);
  }
}
function splitTopLevel(source, ast) {
  const nodes = ast.program.body;
  if (!nodes.length) die("Source contains no top-level statements.");
  const chunks = [];
  let current = "";
  let types = [];
  const flush = () => {
    if (current.trim()) chunks.push({code: current, types});
    current = "";
    types = [];
  };
  for (const node of nodes) {
    const piece = source.slice(node.start, node.end) + "\n";
    if (bytes(piece) > LIMIT)
      die(`One top-level AST node is ${bytes(piece)} bytes, above ${LIMIT}. Node: ${node.type}`);
    if (bytes(current + piece) > LIMIT) flush();
    current += piece;
    types.push(node.type);
  }
  flush();
  return chunks;
}
async function callJShaman(code, n) {
  let last = "";
  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const body = new URLSearchParams({js_code: code, vip_code: "free"});
      const res = await fetch(API, {
        method: "POST",
        headers: {"content-type": "application/x-www-form-urlencoded"},
        body,
        signal: AbortSignal.timeout(120000)
      });
      const text = await res.text();
      if (!res.ok) {
        last = `HTTP ${res.status}: ${text.slice(0,300)}`;
        if (![408,429,500,502,503,504].includes(res.status)) break;
      } else {
        let data;
        try { data = JSON.parse(text); }
        catch { last = `non-JSON response: ${text.slice(0,300)}`; }
        if (data) {
          if (data.status === 0 && typeof data.content === "string" && data.content.trim())
            return data.content;
          last = `API status=${data.status}; ${data.message || "empty content"}`;
          if (data.status !== 0) break;
        }
      }
    } catch (e) {
      last = e.message;
    }
    if (attempt < 3) await sleep(attempt * 3000);
  }
  die(`JShaman failed on chunk ${n} after 3 attempts: ${last}`);
}

function structuralCheck(code) {
  if (!/\bexport\s+default\b/.test(code))
    die("Final output is missing 'export default'.");
  // JShaman may Unicode-escape the module specifier, so inspect both literal
  // and escaped forms instead of requiring the literal text.
  const hasSockets =
    code.includes("cloudflare:sockets") ||
    /\\u[0-9a-fA-F]{4}/.test(code) && /cloudflare/i.test(
      code.replace(/\\u([0-9a-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h,16)))
    );
  if (!hasSockets) die("Final output does not appear to contain cloudflare:sockets.");
}

const source = await fs.readFile(INPUT, "utf8");
if (!source.trim()) die(`Input is empty: ${INPUT}`);

console.log(`[1/6] Source: ${INPUT}`);
console.log(`      bytes=${bytes(source)} sha256=${sha256(source)}`);

const ast = parseJS(source);
const chunks = splitTopLevel(source, ast);
console.log(`[2/6] AST split complete: ${chunks.length} chunk(s)`);

const results = [];
for (let i = 0; i < chunks.length; i++) {
  console.log(`[3/6] JShaman ${i+1}/${chunks.length}: ${bytes(chunks[i].code)} bytes`);
  results.push(await callJShaman(chunks[i].code, i + 1));
}

const finalCode = results.join("\n\n") + "\n";
const temp = `${OUTPUT}.tmp`;
await fs.writeFile(temp, finalCode, "utf8");
console.log(`[4/6] Temporary output: ${bytes(finalCode)} bytes`);

try {
  const { execFile } = await import("node:child_process");
  await new Promise((resolve, reject) =>
    execFile("node", ["--check", temp], (err, stdout, stderr) =>
      err ? reject(new Error(stderr || err.message)) : resolve()
    )
  );
} catch (e) {
  await fs.rm(temp, {force:true});
  die(`Final syntax check failed; existing ${OUTPUT} was not changed. ${e.message}`);
}

try {
  structuralCheck(finalCode);
  // Parse the complete result too; this catches module-level grammar errors
  // that are not necessarily reported by node --check in every runtime.
  parseJS(finalCode);
} catch (e) {
  await fs.rm(temp, {force:true});
  die(`Final structural validation failed; existing ${OUTPUT} was not changed. ${e.message}`);
}

await fs.rename(temp, OUTPUT);
console.log(`[5/6] Validation passed; replaced ${OUTPUT}.`);
console.log(`[6/6] Final bytes=${bytes(finalCode)} sha256=${sha256(finalCode)}`);
