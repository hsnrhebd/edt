# JShaman V2.1 Builder

This builder processes a JavaScript Worker source file already present in the repository.

Usage:

```bash
npm install @babel/parser
node tools/novel-build.mjs origin.js _worker.js
```

The builder:
- parses the source as an ES module;
- splits only between complete top-level AST nodes;
- keeps each submission below 450 KiB;
- submits chunks sequentially to JShaman's free API;
- retries transient failures up to 3 times;
- validates the complete result before replacing `_worker.js`.

It does not download or retrieve third-party source code.

JShaman's official site documents the free Web API endpoint and a 512 KB submission limit.
