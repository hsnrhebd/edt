#!/usr/bin/env node
/*
  JShaman V2 Builder
  Purpose: protect a user-supplied Cloudflare Worker source file.
  Input:  worker-source.js (default)
  Output: _worker.js (default)

  The builder splits only at complete top-level AST statements.
  It never cuts through a function/class/block.
*/

import fs from "node:fs/promises";
import crypto from "node:crypto";
import { parse } from "@babel/parser";

const INPUT = process.argv[2] || "worker-source.js";
const OUTPUT = process.argv[3] || "_worker.js";
const LIMIT = 450 * 1024;
const API = "https://www.jshaman.com:4430/submit_js_code/";

function die(msg) {
  console.error(`ERROR: ${msg}`);
  process.exit(1);
}

function sha256(s) {
  return crypto.createHash("sha256").update(s).digest("hex");
}

async function jshaman(code, n) {
  const body = new URLSearchParams();
  body.set("js_code", code);
  body.set("vip_code", "free");

  let res;
  try {
    res = await fetch(API, {
      method: "POST",
      headers: {"content-type": "application/x-www-form-urlencoded"},
      body,
      signal: AbortSignal.timeout(120000)
    });
  } catch (e) {
    die(`JShaman request failed for chunk ${n}: ${e.message}`);
  }

  const text = await res.text();
  if (!res.ok) die(`JShaman HTTP ${res.status} for chunk ${n}: ${text.slice(0,500)}`);

  let data;
  try { data = JSON.parse(text); }
  catch { die(`JShaman returned non-JSON for chunk ${n}: ${text.slice(0,500)}`); }

  if (data.status !== 0) {
    die(`JShaman rejected chunk ${n}: ${data.message || "unknown error"}`);
  }
  if (typeof data.content !== "string" || !data.content.trim()) {
    die(`JShaman returned empty content for chunk ${n}`);
  }
  return data.content;
}

function parseSource(source) {
  try {
    return parse(source, {
      sourceType: "module",
      allowAwaitOutsideFunction: true,
      plugins: [
        "asyncGenerators", "bigInt", "classProperties", "classPrivateProperties",
        "classPrivateMethods", "dynamicImport", "exportDefaultFrom",
        "exportNamespaceFrom", "importMeta", "logicalAssignment",
        "nullishCoalescingOperator", "optionalChaining", "topLevelAwait",
        "objectRestSpread", "numericSeparator", "optionalCatchBinding"
      ]
    });
  } catch (e) {
    die(`Babel parser failed: ${e.message}`);
  }
}

function splitTopLevel(source, ast) {
  const nodes = ast.program.body;
  if (!nodes.length) die("Source contains no top-level statements.");

  const chunks = [];
  let current = "";
  let currentNodes = [];

  const flush = () => {
    if (current.trim()) chunks.push({code: current, nodes: currentNodes});
    current = "";
    currentNodes = [];
  };

  for (const node of nodes) {
    const piece = source.slice(node.start, node.end) + "\n";
    if (Buffer.byteLength(piece) > LIMIT) {
      die(`A single top-level AST node is ${Buffer.byteLength(piece)} bytes, above the ${LIMIT}-byte safe chunk limit. Node type: ${node.type}`);
    }

    if (Buffer.byteLength(current + piece) > LIMIT) flush();

    current += piece;
    currentNodes.push(node.type);
  }
  flush();
  return chunks;
}

function basicChecks(code) {
  if (!/\bexport\s+default\b/.test(code)) die("Final output is missing export default.");
  if (!/cloudflare:sockets/.test(code)) die("Final output is missing cloudflare:sockets.");
}

const source = await fs.readFile(INPUT, "utf8");
if (!source.trim()) die(`Input is empty: ${INPUT}`);

console.log(`[1/6] Input: ${INPUT}`);
console.log(`      bytes=${Buffer.byteLength(source)} sha256=${sha256(source)}`);

const ast = parseSource(source);
const chunks = splitTopLevel(source, ast);
console.log(`[2/6] AST parsed; chunks=${chunks.length}`);

let out = [];
for (let i = 0; i < chunks.length; i++) {
  const c = chunks[i];
  console.log(`[3/6] JShaman chunk ${i+1}/${chunks.length}: ${Buffer.byteLength(c.code)} bytes`);
  out.push(await jshaman(c.code, i + 1));
}

const finalCode = out.join("\n\n");
await fs.writeFile(OUTPUT, finalCode, "utf8");

console.log(`[4/6] Wrote ${OUTPUT}: ${Buffer.byteLength(finalCode)} bytes`);

try {
  const cp = await import("node:child_process");
  await new Promise((resolve, reject) => {
    cp.execFile("node", ["--check", OUTPUT], (err, stdout, stderr) =>
      err ? reject(new Error(stderr || err.message)) : resolve()
    );
  });
} catch (e) {
  die(`Final node --check failed: ${e.message}`);
}

basicChecks(finalCode);
console.log("[5/6] Syntax and Worker structure checks passed.");
console.log(`[6/6] Final sha256=${sha256(finalCode)}`);
