# JShaman V2 Builder

This package protects a user-supplied Cloudflare Worker source file using JShaman's
free code-submission API. It splits only at complete top-level JavaScript AST nodes;
it never byte-cuts a function or block.

Usage:
  node tools/novel-build.mjs worker-source.js _worker.js

The builder intentionally does not download third-party source automatically.
Place the Worker source you are authorized to modify in the repository and let
the workflow process that file.

Requirements:
  Node.js 22+
  npm packages: @babel/parser
  Network access to https://www.jshaman.com:4430/submit_js_code/

The JShaman free service has a 512 KB submission limit. This builder uses a
450 KiB safety target. If one indivisible top-level AST node is larger than that,
the build fails with a diagnostic instead of producing potentially broken code.
