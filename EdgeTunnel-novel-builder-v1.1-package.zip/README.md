# EdgeTunnel Novel Builder v1.1

Fixes v1.1:
- More tolerant `cloudflare:sockets` import parser.
- Supports multi-line static import formatting.
- Automatically repeats the carrier when the current EdgeTunnel source is larger than one novel.
- Uses 1400-character payload chunks to reduce startup reconstruction overhead.
- Fails with diagnostics for unsupported static imports, missing export default, insufficient carrier capacity, and reconstruction mismatch.
