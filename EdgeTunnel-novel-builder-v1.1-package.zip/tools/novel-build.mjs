import fs from 'node:fs/promises';
import crypto from 'node:crypto';

const [srcPath = 'origin-new.js', outPath = '_worker.js'] = process.argv.slice(2);
const CARRIER_URL = 'https://www.gutenberg.org/cache/epub/1260/pg1260.txt';
const VERSION = process.env.OBFUSCATION_VERSION || 'novel-v1.1';
const CHUNK_SIZE = 1400;
const SEED = 20261016;

function fail(msg) { console.error(`ERROR: ${msg}`); process.exit(1); }
function seeded(seed) {
  let x = seed >>> 0;
  return () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return (x >>> 0) / 4294967296; };
}
function shuffle(a, rnd) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rnd() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}
function sha256(s) { return crypto.createHash('sha256').update(s).digest('hex'); }

function transformSource(src) {
  let body = src.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');

  // More tolerant than v1: accepts one-line, multi-line, spaces, and quote styles.
  const socketRe = /(^|\n)[ \t]*import\s*\{([\s\S]*?)\}\s*from\s*["']cloudflare:sockets["'][ \t]*;?[ \t]*(?=\n|$)/g;
  const sockets = [...body.matchAll(socketRe)];

  if (sockets.length !== 1) {
    fail(`Expected exactly one cloudflare:sockets import, found ${sockets.length}.`);
  }

  const spec = sockets[0][2].trim();
  const bindings = spec.split(',').map(x => x.trim()).filter(Boolean).map(x => {
    const m = x.match(/^([A-Za-z_$][\w$]*)(?:\s+as\s+([A-Za-z_$][\w$]*))?$/);
    if (!m) fail(`Unsupported cloudflare:sockets import item: ${x}`);
    return m[2] ? `${m[1]}: ${m[2]}` : m[1];
  });

  // Reject other static imports; dynamic import() is left untouched.
  const staticImports = [...body.matchAll(/(^|\n)[ \t]*import\s+(?!\()[^;\n]*(?:;|$)/g)];
  for (const m of staticImports) {
    const text = m[0];
    if (!/from\s*["']cloudflare:sockets["']/.test(text)) {
      fail(`Unsupported static import detected: ${text.trim().slice(0, 200)}`);
    }
  }

  body = body.replace(socketRe, '$1');

  const exp = body.match(/(^|\n)[ \t]*export\s+default\s+/m);
  if (!exp) fail('No top-level export default found.');
  body = body.replace(/(^|\n)[ \t]*export\s+default\s+/, '$1return ');

  body = `const { ${bindings.join(', ')} } = __SOCKETS;\n${body.trim()}\n`;
  return body;
}

const src = await fs.readFile(srcPath, 'utf8').catch(() => null);
if (!src) fail(`Cannot read source file: ${srcPath}`);
const body = transformSource(src);

const carrierRes = await fetch(CARRIER_URL);
if (!carrierRes.ok) fail(`Carrier download failed: HTTP ${carrierRes.status}`);
let carrier = await carrierRes.text();
const start = carrier.indexOf('*** START OF THE PROJECT GUTENBERG EBOOK');
const end = carrier.indexOf('*** END OF THE PROJECT GUTENBERG EBOOK');
if (start < 0 || end < 0 || end <= start) fail('Carrier markers not found.');
carrier = carrier.slice(carrier.indexOf('\n', start) + 1, end).replace(/\r\n?/g, '\n').trim();
if (carrier.length < 500000) fail(`Carrier unexpectedly short: ${carrier.length} chars`);

const chunks = [];
for (let i = 0; i < body.length; i += CHUNK_SIZE) chunks.push(body.slice(i, i + CHUNK_SIZE));

const containerCount = chunks.length + 64;
const minimumContainerSize = CHUNK_SIZE + 32;
const repeats = Math.ceil((containerCount * minimumContainerSize) / carrier.length);
const expandedCarrier = carrier.repeat(Math.max(1, repeats));
const base = Math.ceil(expandedCarrier.length / containerCount);
if (base < minimumContainerSize) fail(`Carrier capacity too small: ${base} chars/container.`);

const rnd = seeded(SEED);
const containers = Array.from({ length: containerCount }, (_, i) =>
  expandedCarrier.slice(i * base, Math.min(expandedCarrier.length, (i + 1) * base))
);
const slots = shuffle(Array.from({ length: containerCount }, (_, i) => i), rnd).slice(0, chunks.length);
const placements = [];

for (let i = 0; i < chunks.length; i++) {
  const ci = slots[i];
  const text = containers[ci];
  const maxPos = Math.max(10, text.length - chunks[i].length - 10);
  const pos = 10 + Math.floor(rnd() * Math.max(1, maxPos - 9));
  containers[ci] = text.slice(0, pos) + chunks[i] + text.slice(pos);
  placements.push([ci, pos, chunks[i].length]);
}

const containerOrder = shuffle(Array.from({ length: containerCount }, (_, i) => i), rnd);
const remap = new Map(containerOrder.map((old, ni) => [old, ni]));
const finalContainers = containerOrder.map(i => containers[i]);
const finalIndex = placements.map(([ci, off, len]) => [remap.get(ci), off, len]);
const reconstructed = finalIndex.map(([ci, off, len]) => finalContainers[ci].slice(off, off + len)).join('');
if (reconstructed !== body) fail('Internal reconstruction check failed.');

const header = `// Novel container build ${VERSION}\n// Source SHA256: ${sha256(src)}\n// Payload SHA256: ${sha256(body)}\n// Containers: ${finalContainers.length}; chunks: ${finalIndex.length}; chunkSize: ${CHUNK_SIZE}\n// Carrier: Project Gutenberg #1260 (Jane Eyre), repeated as needed for payload capacity\n// Requires Workers compatibility_date >= 2025-06-01 for startup dynamic evaluation.\n`;
const out = `${header}import{connect as _c}from"cloudflare:sockets";\nconst _b=${JSON.stringify(finalContainers)};\nconst _m=${JSON.stringify(finalIndex)};\nconst _j=()=>{let _s="";for(let _i=0;_i<_m.length;_i++){const _e=_m[_i];_s+=_b[_e[0]].slice(_e[1],_e[1]+_e[2]);}return _s;};\nconst _F=Object.getPrototypeOf(async function(){}).constructor;\nconst _h=await new _F("__SOCKETS",_j())({connect:_c});\nexport default _h;\n`;
await fs.writeFile(outPath, out);
console.log(`OK: ${outPath}`);
console.log(`Source bytes: ${Buffer.byteLength(src)}; payload chars: ${body.length}`);
console.log(`Containers: ${finalContainers.length}; chunks: ${finalIndex.length}; chunkSize: ${CHUNK_SIZE}`);
console.log(`Carrier repeats: ${repeats}; container base: ${base}`);
console.log(`Output bytes: ${Buffer.byteLength(out)}`);
console.log(`Source SHA256: ${sha256(src)}`);
console.log(`Payload SHA256: ${sha256(body)}`);
