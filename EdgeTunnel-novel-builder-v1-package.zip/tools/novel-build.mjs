import fs from 'node:fs/promises';
import crypto from 'node:crypto';

const [srcPath = 'origin-new.js', outPath = '_worker.js'] = process.argv.slice(2);
const CARRIER_URL = 'https://www.gutenberg.org/cache/epub/1260/pg1260.txt';
const VERSION = process.env.OBFUSCATION_VERSION || 'novel-v1';
const CONTAINERS = 900;
const CHUNK_SIZE = 450;
const SEED = 20261016;

function fail(msg) { console.error(`ERROR: ${msg}`); process.exit(1); }
function seeded(seed) {
  let x = seed >>> 0;
  return () => { x ^= x << 13; x ^= x >>> 17; x ^= x << 5; return (x >>> 0) / 4294967296; };
}
function shuffle(a, rnd) {
  for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
}
function sha256(s) { return crypto.createHash('sha256').update(s).digest('hex'); }

function transformSource(src) {
  let body = src.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n');
  const imports = [...body.matchAll(/^\s*import\s*\{([\s\S]*?)\}\s*from\s*["']cloudflare:sockets["']\s*;?\s*$/gm)];
  const otherImports = [...body.matchAll(/^\s*import\s+.+?\s+from\s+["']([^"']+)["']\s*;?\s*$/gm)];
  if (otherImports.some(m => m[1] !== 'cloudflare:sockets')) fail(`Unsupported import detected: ${otherImports.find(m => m[1] !== 'cloudflare:sockets')[1]}`);
  if (imports.length !== 1) fail(`Expected exactly one cloudflare:sockets import, found ${imports.length}.`);
  const spec = imports[0][1].trim();
  body = body.replace(imports[0][0], '');
  const bindings = spec.split(',').map(x => x.trim()).filter(Boolean).map(x => {
    const m = x.match(/^([A-Za-z_$][\w$]*)(?:\s+as\s+([A-Za-z_$][\w$]*))?$/);
    if (!m) fail(`Unsupported sockets import syntax: ${x}`);
    return m[2] ? `${m[1]}: ${m[2]}` : m[1];
  });
  const exp = body.match(/^\s*export\s+default\s+/m);
  if (!exp) fail('No top-level export default found.');
  body = body.replace(/^\s*export\s+default\s+/m, 'return ');
  body = `const { ${bindings.join(', ')} } = __SOCKETS;\n${body.trim()}\n`;
  return body;
}

const src = await fs.readFile(srcPath, 'utf8').catch(() => null);
if (!src) fail(`Cannot read source file: ${srcPath}`);
const body = transformSource(src);

const carrierRes = await fetch(CARRIER_URL);
if (!carrierRes.ok) fail(`Carrier download failed: HTTP ${carrierRes.status}`);
let carrier = await carrierRes.text();
const start = carrier.indexOf('*** START OF THE PROJECT GUTENBERG EBOOK');
const end = carrier.indexOf('*** END OF THE PROJECT GUTENBERG EBOOK');
if (start < 0 || end < 0 || end <= start) fail('Carrier markers not found.');
carrier = carrier.slice(carrier.indexOf('\n', start) + 1, end).replace(/\r\n?/g, '\n').trim();
if (carrier.length < 500000) fail(`Carrier unexpectedly short: ${carrier.length} chars`);

const chunks = [];
for (let i = 0; i < body.length; i += CHUNK_SIZE) chunks.push(body.slice(i, i + CHUNK_SIZE));
const containerCount = Math.max(CONTAINERS, chunks.length + 64);
if (chunks.length >= containerCount) fail(`Too many chunks (${chunks.length}) for ${containerCount} containers.`);

const rnd = seeded(SEED);
const base = Math.ceil(carrier.length / containerCount);
const containers = Array.from({ length: containerCount }, (_, i) => carrier.slice(i * base, Math.min(carrier.length, (i + 1) * base)));
const slots = shuffle(Array.from({ length: containerCount }, (_, i) => i), rnd).slice(0, chunks.length);
const placements = [];
for (let i = 0; i < chunks.length; i++) {
  const ci = slots[i];
  const text = containers[ci];
  const pos = text.length <= 20 ? 0 : 10 + Math.floor(rnd() * (text.length - 20));
  containers[ci] = text.slice(0, pos) + chunks[i] + text.slice(pos);
  placements.push([ci, pos, chunks[i].length]);
}

// Randomize the physical container order; _m keeps the original code order.
const containerOrder = shuffle(Array.from({ length: containerCount }, (_, i) => i), rnd);
const remap = new Map(containerOrder.map((old, ni) => [old, ni]));
const finalContainers = containerOrder.map(i => containers[i]);
const finalIndex = placements.map(([ci, off, len]) => [remap.get(ci), off, len]);
const reconstructed = finalIndex.map(([ci, off, len]) => finalContainers[ci].slice(off, off + len)).join('');
if (reconstructed !== body) fail('Internal reconstruction check failed.');

const header = `// Novel container build ${VERSION}\n// Source SHA256: ${sha256(src)}\n// Payload SHA256: ${sha256(body)}\n// Containers: ${finalContainers.length}; chunks: ${finalIndex.length}; chunkSize: ${CHUNK_SIZE}\n// Carrier: Project Gutenberg #1260 (Jane Eyre), public-domain source text\n// Requires Workers compatibility_date >= 2025-06-01 for startup dynamic evaluation.\n`;
const out = `${header}import{connect as _c}from"cloudflare:sockets";\nconst _b=${JSON.stringify(finalContainers)};\nconst _m=${JSON.stringify(finalIndex)};\nconst _j=()=>{let _s="";for(let _i=0;_i<_m.length;_i++){const _e=_m[_i];_s+=_b[_e[0]].slice(_e[1],_e[1]+_e[2]);}return _s;};\nconst _F=Object.getPrototypeOf(async function(){}).constructor;\nconst _h=await new _F("__SOCKETS",_j())({connect:_c});\nexport default _h;\n`;
await fs.writeFile(outPath, out);
console.log(`OK: ${outPath}`);
console.log(`Source bytes: ${Buffer.byteLength(src)}; payload chars: ${body.length}`);
console.log(`Containers: ${finalContainers.length}; chunks: ${finalIndex.length}; output bytes: ${Buffer.byteLength(out)}`);
console.log(`Source SHA256: ${sha256(src)}`);
console.log(`Payload SHA256: ${sha256(body)}`);
