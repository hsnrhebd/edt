# EdgeTunnel 小说式分片构建器

这套构建器不是 javascript-obfuscator。它把 EdgeTunnel 的可执行代码改造成：

1. 提取 `cloudflare:sockets` 的静态 import；
2. 把 Worker 主体转换为可在启动阶段执行的 `AsyncFunction`；
3. 从 Project Gutenberg #1260 下载《Jane Eyre》正文作为载体；
4. 将 Worker 主体按 450 字符切片；
5. 将每个代码片段随机嵌入不同小说容器；
6. 随机打乱容器物理顺序；
7. 生成 `_m = [[容器,偏移,长度], ...]`；
8. 启动时按 `_m` 顺序重组并一次性动态编译；
9. 构建阶段进行重组 SHA/完整字符串校验和 `node --check`。

Cloudflare Workers 的 `allow_eval_during_startup` 自 2025-06-01 起默认开启；部署工作流显式指定 2026-10-16 compatibility date。

## 文件

- `tools/novel-build.mjs`：核心构建器
- `.github/workflows/build-novel.yml`：自动构建
- `.github/workflows/deploy-novel.yml`：手动部署

## 注意

动态代码执行只发生在 Worker 启动阶段；不要在请求处理阶段新增 `eval` / `new Function`。

载体文本来自 Project Gutenberg #1260。使用前请按你所在地区的法律和 Project Gutenberg 的许可条款确认适用性。
